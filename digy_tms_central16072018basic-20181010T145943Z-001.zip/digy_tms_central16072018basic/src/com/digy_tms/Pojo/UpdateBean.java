package com.digy_tms.Pojo;

public class UpdateBean {

private String Course_key;
	

	private String Course_id;
	private String Course_name;
	private String Course_short_name;
	private String Course_type;
	private String Course_category;
	private String Course_sub_category;
	private String Course_duration_uom;
	private String Course_duration_min;
	private String Course_duration_max;
	private String Curese_buffer_01;
	private String Curese_buffer_02;
	private String Curese_buffer_03;
	private String Curese_buffer_04;
	private String Curese_buffer_05;
	private String Course_Status;
	private String Course_created_by;
	private String Course_created_DtTm;
	private String Course_mod_by;
	private String Course_mod_DtTm;
	
	public String getCourse_key() {
		return Course_key;
	}
	public void setCourse_key(String course_key2) {
		Course_key = course_key2;
	}
	
	public String getCourse_id() {
		return Course_id;
	}
	public void setCourse_id(String course_id) {
		Course_id = course_id;
	}
	public String getCourse_name() {
		return Course_name;
	}
	public void setCourse_name(String course_name) {
		Course_name = course_name;
	}
	public String getCourse_short_name() {
		return Course_short_name;
	}
	public void setCourse_short_name(String course_short_name) {
		Course_short_name = course_short_name;
	}
	public String getCourse_type() {
		return Course_type;
	}
	public void setCourse_type(String course_type) {
		Course_type = course_type;
	}
	public String getCourse_category() {
		return Course_category;
	}
	public void setCourse_category(String course_category) {
		Course_category = course_category;
	}
	public String getCourse_sub_category() {
		return Course_sub_category;
	}
	public void setCourse_sub_category(String course_sub_category) {
		Course_sub_category = course_sub_category;
	}
	public String getCourse_duration_uom() {
		return Course_duration_uom;
	}
	public void setCourse_duration_uom(String course_duration_uom) {
		Course_duration_uom = course_duration_uom;
	}
	public String getCourse_duration_min() {
		return Course_duration_min;
	}
	public void setCourse_duration_min(String course_duration_min) {
		Course_duration_min = course_duration_min;
	}
	public String getCourse_duration_max() {
		return Course_duration_max;
	}
	public void setCourse_duration_max(String course_duration_max) {
		Course_duration_max = course_duration_max;
	}
	public String getCurese_buffer_01() {
		return Curese_buffer_01;
	}
	public void setCurese_buffer_01(String curese_buffer_01) {
		Curese_buffer_01 = curese_buffer_01;
	}
	public String getCurese_buffer_02() {
		return Curese_buffer_02;
	}
	public void setCurese_buffer_02(String curese_buffer_02) {
		Curese_buffer_02 = curese_buffer_02;
	}
	public String getCurese_buffer_03() {
		return Curese_buffer_03;
	}
	public void setCurese_buffer_03(String curese_buffer_03) {
		Curese_buffer_03 = curese_buffer_03;
	}
	public String getCurese_buffer_04() {
		return Curese_buffer_04;
	}
	public void setCurese_buffer_04(String curese_buffer_04) {
		Curese_buffer_04 = curese_buffer_04;
	}
	public String getCurese_buffer_05() {
		return Curese_buffer_05;
	}
	public void setCurese_buffer_05(String curese_buffer_05) {
		Curese_buffer_05 = curese_buffer_05;
	}
	public String getCourse_Status() {
		return Course_Status;
	}
	public void setCourse_Status(String course_Status) {
		Course_Status = course_Status;
	}
	public String getCourse_created_by() {
		return Course_created_by;
	}
	public void setCourse_created_by(String course_created_by) {
		Course_created_by = course_created_by;
	}
	public String getCourse_created_DtTm() {
		return Course_created_DtTm;
	}
	public void setCourse_created_DtTm(String course_created_DtTm) {
		Course_created_DtTm = course_created_DtTm;
	}
	public String getCourse_mod_by() {
		return Course_mod_by;
	}
	public void setCourse_mod_by(String course_mod_by) {
		Course_mod_by = course_mod_by;
	}
	public String getCourse_mod_DtTm() {
		return Course_mod_DtTm;
	}
	public void setCourse_mod_DtTm(String course_mod_DtTm) {
		Course_mod_DtTm = course_mod_DtTm;
	}
	
	
	
}
