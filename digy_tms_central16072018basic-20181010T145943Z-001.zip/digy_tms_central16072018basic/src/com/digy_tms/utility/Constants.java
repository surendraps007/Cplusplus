package com.digy_tms.utility;

public interface Constants {
	
	static String mode="sandbox";
	static String clientId = "AZ8KN_W_y7OSonsTJzHiKkiGuBK4ha7jF_Tu3XHzA-JQgLUCBs0smx3s7wleUw-3vIGe7EPNKoY-Z_gj";
	static String clientSecret = "EPpfNAp4ibsv8r-kVvFupeJyXpiQI-wKoOcP85meW0M4lbAZPp0nfgSUVK2idYDCXM3OUVNHr_-fXjxw";
	static String return_url="http://localhost:8080/JCBPointIntegration/Paypal";
	static String cancel_url="http://localhost:8080/JCBPointIntegration/";
	
}
